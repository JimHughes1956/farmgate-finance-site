export default function HomePage() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Farmgate Finance</h1>
      <p>Welcome to the homepage (replace this with your full design).</p>
    </div>
  );
}