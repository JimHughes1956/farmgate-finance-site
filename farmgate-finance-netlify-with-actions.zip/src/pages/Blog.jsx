export default function Blog() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Farm Finance Insights</h1>
      <ul className="list-disc pl-6 space-y-2">
        <li>📅 May 2025 – How invoice finance boosts your cash flow</li>
        <li>📅 April 2025 – Tips for dairy farm liquidity</li>
      </ul>
    </div>
  );
}