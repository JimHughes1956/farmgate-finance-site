export default function FAQ() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Frequently Asked Questions</h1>
      <ul className="space-y-4">
        <li><strong>How does Farmgate Finance work?</strong> We pay 100% upfront on your milk payments...</li>
        <li><strong>Is this only for Fonterra farmers?</strong> Yes, currently.</li>
      </ul>
    </div>
  );
}