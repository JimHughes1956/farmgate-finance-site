export default function Apply() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Apply for Finance</h1>
      <p>Fill in the application form (coming soon!)</p>
    </div>
  );
}