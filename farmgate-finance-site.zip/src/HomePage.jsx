import { useState } from 'react';

export default function HomePage() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');

  const [litres, setLitres] = useState(0);
  const [rate, setRate] = useState(0);
  const [quote, setQuote] = useState(null);

  const handleLogin = () => {
    if (email === 'demo@farmgate.com' && password === 'password123') {
      setLoggedIn(true);
      setError('');
    } else {
      setError('Invalid credentials. Use demo@farmgate.com / password123');
    }
  };

  const handleQuote = () => {
    const total = parseFloat(litres) * parseFloat(rate);
    setQuote(total.toFixed(2));
  };

  const handleContactSubmit = (e) => {
    e.preventDefault();
    alert(`Message sent by ${contactName}`);
  };

  return (
    <div className="font-inter bg-white text-gray-800">
      <nav className="bg-white shadow px-6 py-4 text-sm text-gray-800 flex justify-between items-center">
        <div className="font-bold text-lg text-green-700">Farmgate Finance</div>
        <div className="space-x-4">
          <a href="#" className="hover:underline">Home</a>
          <a href="#how" className="hover:underline">How It Works</a>
          <a href="#faq" className="hover:underline">FAQ</a>
          <a href="#contact" className="hover:underline">Contact</a>
          <a href="#login" className="text-green-700 font-semibold hover:underline">Client Login</a>
        </div>
      </nav>

      <section className="bg-green-100 py-16 px-6 text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Get Paid 100% Upfront for Your Milk Today</h1>
        <p className="text-lg md:text-xl mb-6">Fast, simple invoice finance for Fonterra dairy farmers. Daily, weekly or monthly cash flow with no waiting.</p>
        <a href="#how" className="bg-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-green-700 transition">How It Works</a>
      </section>

      <section id="how" className="py-16 px-6 max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-10">How It Works</h2>
        <div className="grid md:grid-cols-4 gap-8 text-center">
          {[
            ['Supply Your Milk', 'You supply milk to Fonterra as usual.'],
            ['Your farm's data is uploaded', 'Your information is uploaded from Fonterra automatically.'],
            ['We Advance you 100%', 'We pay you 100% of the receivable (including Retro) amount upfront.'],
            ['We Collect from Fonterra', 'Fonterra pays us directly on your behalf.']
          ].map(([title, desc], i) => (
            <div key={i}>
              <div className="text-green-600 text-4xl font-bold mb-2">{i + 1}</div>
              <p className="font-semibold mb-2">{title}</p>
              <p className="text-sm text-gray-600">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-gray-50 py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Why Choose Farmgate Finance?</h2>
          <ul className="text-left text-gray-700 space-y-4">
            <li>✅ Get 100% of your dairy payments (including Retros) now – no waiting</li>
            <li>✅ Daily, weekly or monthly payments to suit your farm's cashflow requirements</li>
            <li>✅ Trusted by NZ dairy farmers</li>
            <li>✅ Easy and simple onboarding process</li>
          </ul>
        </div>
      </section>

      <section id="quote" className="py-16 px-6 text-center bg-green-50">
        <h2 className="text-3xl font-bold mb-6">Instant Quote Calculator</h2>
        <div className="max-w-md mx-auto space-y-4">
          <input type="number" placeholder="Milk Litres" className="w-full border px-4 py-2 rounded" value={litres} onChange={(e) => setLitres(e.target.value)} />
          <input type="number" placeholder="Rate per Litre ($)" className="w-full border px-4 py-2 rounded" value={rate} onChange={(e) => setRate(e.target.value)} />
          <button onClick={handleQuote} className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Calculate</button>
          {quote && <p className="text-green-700 font-semibold">Estimated Advance: ${quote}</p>}
        </div>
      </section>

      <section id="login" className="py-16 px-6 text-center">
        <h2 className="text-3xl font-bold mb-4">Client Login</h2>
        {loggedIn ? (
          <p className="text-green-700 font-semibold">Welcome back, Client!</p>
        ) : (
          <div className="max-w-md mx-auto">
            <input type="email" className="border border-gray-300 rounded px-4 py-2 mb-2 w-full" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
            <input type="password" className="border border-gray-300 rounded px-4 py-2 mb-2 w-full" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
            {error && <p className="text-red-500 text-sm mb-2">{error}</p>}
            <button onClick={handleLogin} className="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">Login</button>
          </div>
        )}
      </section>

      <section id="contact" className="py-16 px-6 text-center">
        <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
        <p className="mb-2">Email: <a href="mailto:support@farmgatefinance.com" className="text-green-700">support@farmgatefinance.com</a></p>
        <p className="mb-6">Phone: <a href="tel:+64099505891" className="text-green-700">+64 09 9505891</a></p>
        <form onSubmit={handleContactSubmit} className="max-w-lg mx-auto space-y-4">
          <input type="text" placeholder="Name" className="w-full border px-4 py-2 rounded" value={contactName} onChange={(e) => setContactName(e.target.value)} />
          <input type="email" placeholder="Email" className="w-full border px-4 py-2 rounded" value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} />
          <textarea placeholder="Message" className="w-full border px-4 py-2 rounded" value={contactMessage} onChange={(e) => setContactMessage(e.target.value)} />
          <button type="submit" className="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">Send Message</button>
        </form>
      </section>

      <footer className="bg-gray-900 text-gray-300 py-8 px-6 text-center text-sm">
        <p>&copy; 2025 Farmgate Finance. All rights reserved.</p>
      </footer>
    </div>
  );
}